 import 'dart:ui';




const BlueColour=Color(0xFF407CE2);
   const Color blackColour=Color(0xFF221F1F);
     const Color greyColour=Color(0xFFA1A8B0);
     const Color whiteColour=Color(0xFFFFFFFF); 


     const Color orangeColour=Color.fromARGB(255, 242, 186, 101);
       const Color BorderColour= Color.fromRGBO(34, 31, 31, 0.1);
        const Color fillColour=Color.fromARGB(255, 221, 229, 237);
          const Color fillColour2=Color.fromARGB(255, 11, 65, 94);
          const Color fillColour3=Color.fromARGB(115, 45, 39, 39);
         const Color newColour=Color.fromRGBO(34, 31, 31, 0.4);
         const Color backgroundColor=const Color.fromARGB(255, 83, 86, 87);

          
 
            const Color iconColour=Color.fromRGBO(34, 31, 31, 0.4); 


