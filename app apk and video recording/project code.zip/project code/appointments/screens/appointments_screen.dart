import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:new_firebase_app/video_call/screens/video_call.dart';
import 'package:new_firebase_app/theme/controller/theme_controller.dart';
import 'package:new_firebase_app/session/controller/session_controller.dart';





class AppointmentsScreen extends StatelessWidget {
  AppointmentsScreen({super.key});

  final sessionController = Get.put(SessionController());
  final themeController = Get.find<ThemeController>();

  String formatTimestamp(Timestamp? t) {
    if (t == null) return "-";
    final d = t.toDate();
    return "${d.day}/${d.month}/${d.year} "
        "${d.hour}:${d.minute.toString().padLeft(2, '0')}";
  }

  String formatDuration(int sec) =>
      "${sec ~/ 60}m ${sec % 60}s";

  @override
  Widget build(BuildContext context) {
    final isDark = themeController.isDark.value;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Upcoming Sessions",
        ),
         actions: [
          Obx(() => IconButton(
                icon: Icon(
                  themeController.isDark.value
                      ? Icons.light_mode
                      : Icons.dark_mode,
                ),
                onPressed: themeController.toggleTheme,
              )),
        ],
        backgroundColor: isDark ? Colors.black : Colors.blue,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: sessionController.repo.getSessions(),
        builder: (_, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text("No sessions found"));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final data =
                  docs[i].data() as Map<String, dynamic>;

              final title = data['title'] ?? 'Untitled';
              final status = data['status'] ?? 'upcoming';
              final duration = data['totalDuration'] ?? 0;

              final Timestamp? start = data['lastCallStart'];
              final Timestamp? end = data['lastCallEnd'];

              return Card(
                child: ListTile(
                  title: Text(title),
                  subtitle: Text(
                    status == 'completed'
                        ? "Completed\nStart: ${formatTimestamp(start)}\nEnd: ${formatTimestamp(end)}\nDuration: ${formatDuration(duration)}"
                        : status == 'ongoing'
                            ? "Ongoing\nStart: ${formatTimestamp(start)}"
                            : "Upcoming",
                  ),
                  trailing: ElevatedButton(
  style: ElevatedButton.styleFrom(
    backgroundColor: status == 'upcoming'
        ? Colors.green
        : Colors.grey, // ongoing / completed
  ),
  onPressed: status == 'upcoming'
      ? () async {
          await sessionController.joinSession(docs[i].id);
          Get.to(() => VideoCallScreen(
                sessionId: docs[i].id,
              ));
        }
      : null,
  child: Text(
    status == 'upcoming' ? 'Join' : status,
    style: const TextStyle(color: Colors.white),
  ),
),

                  
                ),
              );
            },
          );
        },
      ),
    );
  }
}




