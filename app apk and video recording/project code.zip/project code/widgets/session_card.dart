import 'package:flutter/material.dart';

class SessionCard extends StatelessWidget {
  final String title;
  final VoidCallback onJoin;

  const SessionCard({
    super.key,
    required this.title,
    required this.onJoin,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w600)),
            ),
            ElevatedButton(
              onPressed: onJoin,
              child: const Text("Join"),
            )
          ],
        ),
      ),
    );
  }
}
