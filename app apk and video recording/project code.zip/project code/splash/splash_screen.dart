import 'package:new_firebase_app/constant/imports.dart';
import 'package:new_firebase_app/appointments/screens/appointments_screen.dart';




class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  // final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }
  Future<void> _checkLoginStatus() async {
    await Future.delayed(const Duration(seconds: 2));
         Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) =>  AppointmentsScreen()),
        );

    // if (!mounted) return;

    // final user = _auth.currentUser;

    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   if (user != null) {
    //     // User is logged in
    //     Navigator.pushReplacement(
    //       context,
    //       MaterialPageRoute(builder: (_) => const DashboardScreen()),
    //     );
    //   } else {
    //     // User is not logged in
    //     Navigator.pushReplacement(
    //       context,
    //       MaterialPageRoute(builder: (_) => const LoginPage()),
    //     );
    //   }
    // });
  }


 
  @override
  Widget build(BuildContext context) {
        final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return  Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,

      body: Center(
  child:  SpinKitSpinningLines(
          color: isDarkMode ? AppColors.white : AppColors.black,
          size: 70.0,
          lineWidth: 4.0,
          duration: const Duration(milliseconds: 1200),
        ),
    ));
  }
}
