import 'dart:async';
import 'package:get/get.dart';



class VideoController extends GetxController {
  RxInt seconds = 0.obs;
  Timer? _timer;

  void start() {
    seconds.value = 0;
    _timer?.cancel();
    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => seconds.value++,
    );
  }

  void stop() {
    _timer?.cancel();
  }

  @override
  void onClose() {
    stop();
    super.onClose();
  }
}
