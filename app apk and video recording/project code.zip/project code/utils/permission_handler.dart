import 'package:permission_handler/permission_handler.dart';

class PermissionHelper {
  static Future<bool> checkCameraMic() async {
    final cam = await Permission.camera.request();
    final mic = await Permission.microphone.request();
    return cam.isGranted && mic.isGranted;
  }
}
