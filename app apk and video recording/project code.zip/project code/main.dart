import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:new_firebase_app/splash/splash_screen.dart';
import 'package:new_firebase_app/theme/controller/theme_controller.dart';
import 'package:new_firebase_app/session/controller/session_controller.dart';


void main()async {
    WidgetsFlutterBinding.ensureInitialized();

 if (kIsWeb) {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyDVgZ9-yTZZdKPtxckEQy2aMNpaBJUv6d8",
        projectId: "myproject-6ec92",
        messagingSenderId: "262194486398",
        appId: "1:262194486398:android:b89424b986027539814c2f",
      ),
    );
  } else {
    await Firebase.initializeApp();
  }
    Get.put(SessionController(), permanent: true);

    Get.put(ThemeController(), permanent: true);

    print("Firebase connected successfully!");
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',

      // Light Theme
      theme: ThemeData(
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.light,
        ),
        useMaterial3: true, 
      ),

      // Dark Theme
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),

      themeMode: ThemeMode.system,

      home: const SplashScreen(),
    );
  }
}


