import 'package:cloud_firestore/cloud_firestore.dart';



class SessionRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> createSession(String title) async {
    await _db.collection('sessions').add({
      'title': title,
      'status': 'upcoming',
      'createdAt': Timestamp.now(),
      'lastCallStart': null,
      'lastCallEnd': null,
      'totalDuration': 0,
    });
  }

  /// Start call
  Future<void> startCall(String sessionId) async {
    await _db.collection('sessions').doc(sessionId).update({
      'status': 'ongoing',
      'lastCallStart': Timestamp.now(),
      'lastCallEnd': null,
    });
  }

  /// End call
  Future<void> endCall({
    required String sessionId,
    required int duration,
  }) async {
    final ref = _db.collection('sessions').doc(sessionId);

    await ref.collection('calls').add({
      'startTime': Timestamp.now(),
      'endTime': Timestamp.now(),
      'duration': duration,
    });

    await ref.update({
      'status': 'completed',
      'lastCallEnd': Timestamp.now(),
      'totalDuration': FieldValue.increment(duration),
    });
  }

  /// Sessions for appointments screen
  Stream<QuerySnapshot> getSessions() {
    return _db
        .collection('sessions')
        .orderBy('createdAt', descending: false)
        .snapshots();
  }
}
