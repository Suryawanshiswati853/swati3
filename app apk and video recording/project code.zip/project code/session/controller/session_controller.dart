import 'package:get/get.dart';
import 'package:new_firebase_app/data/repositories/session_repository.dart';


class SessionController extends GetxController {
  final SessionRepository repo = SessionRepository();

  final RxBool isInCall = false.obs;
  final RxString currentSessionId = ''.obs;

  DateTime? _callStart;

  Future<void> joinSession(String sessionId) async {
    if (isInCall.value) return;

    isInCall.value = true;
    currentSessionId.value = sessionId;
    _callStart = DateTime.now();

    await repo.startCall(sessionId);
  }

  Future<void> endCall() async {
    if (!isInCall.value || _callStart == null) return;

    final duration =
        DateTime.now().difference(_callStart!).inSeconds;

    await repo.endCall(
      sessionId: currentSessionId.value,
      duration: duration,
    );

    isInCall.value = false;
    currentSessionId.value = '';
    _callStart = null;
  }
}
