import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:new_firebase_app/video/controller/video_controller.dart';
import 'package:new_firebase_app/session/controller/session_controller.dart';








class VideoCallScreen extends StatelessWidget {
  final String sessionId;
  VideoCallScreen({super.key, required this.sessionId});

  final videoController = Get.put(VideoController());
  final sessionController = Get.find<SessionController>();

  @override
  Widget build(BuildContext context) {
    videoController.start();

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 30),

            // Duration text - center top
            Obx(
              () => Center(
                child: Text(
                  "Duration: ${videoController.seconds.value}s",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const Spacer(),

            // Call icon - EXACT CENTER
            const Center(
              child: Icon(
                Icons.videocam,
                color: Colors.white,
                size: 120,
              ),
            ),

            const Spacer(),

            // End call button - CENTER
            Center(
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 30, vertical: 12),
                ),
                onPressed: () async {
                  videoController.stop();
                  await sessionController.endCall();
                  Get.back();
                },
                icon: const Icon(Icons.call_end),
                label: const Text("End Call"),
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
